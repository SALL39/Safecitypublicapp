import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GreenNumbersPageRoutingModule } from './green-numbers-routing.module';

import { GreenNumbersPage } from './green-numbers.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GreenNumbersPageRoutingModule
  ],
  declarations: [GreenNumbersPage]
})
export class GreenNumbersPageModule {}

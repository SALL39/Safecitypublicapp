import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-green-numbers',
  templateUrl: './green-numbers.page.html',
  styleUrls: ['./green-numbers.page.scss'],
})
export class GreenNumbersPage implements OnInit {
  audio: HTMLAudioElement;

  constructor() { }

  ngOnInit() {
    this.audio = new Audio();
    this.audio.src = '/assets/5.ogg';
    this.audio.load();
    this.audio.play();
  }

  ionViewWillLeave() {
    this.audio.pause();
    this.audio = null;
  }

}

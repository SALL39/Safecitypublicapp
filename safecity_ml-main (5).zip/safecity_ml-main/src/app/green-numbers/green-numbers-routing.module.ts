import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GreenNumbersPage } from './green-numbers.page';

const routes: Routes = [
  {
    path: '',
    component: GreenNumbersPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GreenNumbersPageRoutingModule {}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MyRegularReportPage } from './my-regular-report.page';

const routes: Routes = [
  {
    path: '',
    component: MyRegularReportPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MyRegularReportPageRoutingModule {}

import { isNgTemplate } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { ReportService } from '../service/report.service';

@Component({
  selector: 'app-my-regular-report',
  templateUrl: './my-regular-report.page.html',
  styleUrls: ['./my-regular-report.page.scss'],
})
export class MyRegularReportPage implements OnInit {
  reports: any;
  selectedItem: any;
  audio: HTMLAudioElement;
  play = false
  constructor(private reportSvc: ReportService) { }

  ngOnInit() {
    this.getReports()
    this.audio = new Audio();
    this.audio.src = '/assets/4.ogg';
    this.audio.load();
    this.audio.onended = () =>{
      this.play = false;
    }
  }  

  playAudio() {
    this.audio.play();
    this.play = true;
  }

  pauseAudio() {
    this.audio.pause();
    this.play = false;
  }

  getReports() {
    this.reportSvc.getMyRegularReport().subscribe(
      (res: any) => {
        this.reports = res.data;
        this.reports.map(p => {
          if (p.status == 0) {
            p.statusname = "En attente"
          } else if (p.status == 1) {
            p.statusname = "Traitement"
          } else {
            p.statusname = "Résolu"
          }
        })
      }
    )
  }

  view(item) {
    this.selectedItem = item;
  }

  back() {
    this.selectedItem = null;
  }

  ionViewWillLeave() {
    this.audio.pause();
  }
}

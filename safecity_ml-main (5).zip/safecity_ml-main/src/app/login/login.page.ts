import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ActionSheetController, AlertController } from '@ionic/angular';
import { NotificationService } from '../service/notification.service';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  userForm: FormGroup;
  constructor(private router: Router,
    private notifySvc: NotificationService,
    private alertController: AlertController,
    private userSvc: UserService,
    private fb: FormBuilder) { }

  ngOnInit() {
    this.userForm = this.fb.group({
      phone: ['', [Validators.required]]
    });
  }

  signin() {
    this.userSvc.login(this.userForm.value).subscribe(
      (res: any) => {
        this.showOtpAlert()
      } 
    )
  }


  async showOtpAlert() {
    const alert = await this.alertController.create({
      header: 'Verify OTP',
      inputs: [
        {
          name: 'otp',
          type: 'text',
          placeholder: 'Entrer dans OTP'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Vérifier maintenant',
          handler: (data: any) => {
            this.verifyOtp(data.otp);
          }
        }
      ]
    });

    await alert.present();
  }

  verifyOtp(otp) {
    this.userSvc.verifyOtp({token: otp}).subscribe(
      (res: any) => {
        this.router.navigate(["/"])
      },
      (err: any) => {
        if ("message" in err.error) {
          this.notifySvc.showAlert(err.error.message)
        }
      }
    )
  }

}

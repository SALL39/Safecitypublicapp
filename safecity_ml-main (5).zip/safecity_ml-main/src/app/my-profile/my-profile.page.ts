import { Component, OnInit } from '@angular/core';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.page.html',
  styleUrls: ['./my-profile.page.scss'],
})
export class MyProfilePage implements OnInit {
  user: any = {
    first_name: '',
    last_name: '',
    phone: ''
  };
  audio: HTMLAudioElement;
  play = false;
  constructor(private userSvc: UserService) { }

  ngOnInit() {
    this.getUserDetails()
    const user = JSON.parse(localStorage.getItem("safecity_user"));
    if (user) {
      this.user = user;
    }
    this.audio = new Audio();
    this.audio.src = '/assets/2.ogg';
    this.audio.load();

    this.audio.load();
    this.audio.onended = () =>{
      this.play = false;
    }
  }
  
  playAudio() {
    this.audio.play();
    this.play = true;
  }

  pauseAudio() {
    this.audio.pause();
    this.play = false;
  }
  
  getUserDetails() {
    this.userSvc.getUserInfo().subscribe(
      (res: any) => {
        this.user = res.data;
      }
    )
  }

  update() {
    this.userSvc.updateUserInfo(this.user).subscribe(
      (res: any) => {
        this.getUserDetails()
      }
    )
  }

  ionViewWillLeave() {
    this.audio.pause();
    this.audio = null;
  }
}

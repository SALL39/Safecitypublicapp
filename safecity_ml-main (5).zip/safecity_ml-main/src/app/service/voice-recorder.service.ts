import { Injectable } from '@angular/core';
import { Camera, CameraResultType } from '@capacitor/camera';
import { FileChooser } from '@ionic-native/file-chooser/ngx';
import { IOSFilePicker } from '@ionic-native/file-picker/ngx';

import { Platform } from '@ionic/angular';
import { VoiceRecorder, VoiceRecorderPlugin, RecordingData, GenericResponse, CurrentRecordingStatus } from 'capacitor-voice-recorder';

@Injectable({
  providedIn: 'root'
})
export class VoiceRecorderService {
  audio: any
  recording: boolean;
  isrecording = false;
  constructor(
   ) { 
      
    }

    async checkPermission() {
        const permission = await VoiceRecorder.hasAudioRecordingPermission();
        if (permission.value) {
            return {success: true};
        } else {
            const permission = await VoiceRecorder.requestAudioRecordingPermission();
            if (permission.value) {
                return {success: true};
            } else {
                return {success: false};
            }
        }
    }
    
    async startRecording() {
        try {
            const record = await VoiceRecorder.startRecording();
            if (record.value) {
                this.isrecording = true;
                return {success: true};
            } else {
                return {success: false};
            }
        } catch (error) {
            const permission = await this.checkPermission();
            if (permission) {
                const record = await VoiceRecorder.startRecording();
                if (record.value) {
                    this.isrecording = true;
                    return {success: true};
                } else {
                    return {success: false};
                }
            }
        }
    }

    async stopRecording() {
        if (this.isrecording) {
            const data = await VoiceRecorder.stopRecording();
            return data;
            const base64Sound = data.value.recordDataBase64 // from plugin
            const mimeType = data.value.mimeType  // from plugin
            const audioRef = `data:${mimeType};base64,${base64Sound}`;
            const base64Response = await fetch(`${audioRef}`);
            console.log(await base64Response.blob(), "ppp");
        }
    }
  
}

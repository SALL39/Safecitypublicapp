import { Injectable } from '@angular/core';
import { Platform } from '@ionic/angular';
import { Observable } from 'rxjs';
import { HTTP } from '@ionic-native/http/ngx';
import { HttpClient, HttpEvent, HttpHeaders } from '@angular/common/http';
import { Storage } from '@ionic/storage-angular';
import { StorageService } from './storage.service';

@Injectable({
  providedIn: 'root'
})
export class CrossHttpService {
  token = null;
  constructor(private platform: Platform,
              private nativeHttp: HTTP,
              private httpClient: HttpClient,
              private storage: StorageService
              ) { 

              }
    async loadToken() {
      this.token = localStorage.getItem("safecity_token")
    }      

    get(url): Observable<any> {
      this.token = localStorage.getItem("safecity_token")
      console.log(this.token, "klkl")
      if (this.platform.is('cordova')) {
        const headers = {
          'Content-Type': 'application/json',
        };
        if (this.token) {
          headers['x-safecity-token'] = this.token;
        }
        return Observable.create((observer: any) => {
          this.nativeHttp.get(url, {}, headers).then((res: any) => {
            if (typeof res.data === 'string') {
              res.data = JSON.parse(res.data);
            }
            observer.next(res.data);
          });
        });
      } else {
        console.log(this.token, "zzzz")
        const headers: any = {};
        if (this.token) {
          headers['x-safecity-token'] = this.token
        }
        console.log(headers, 'pp')
        return this.httpClient.get(url, {headers});
      }
  }

  nativeFileUpload(url, postData, headers) {
    if (this.platform.is('cordova')) {
      console.log("here coming")
      return Observable.create((observer: any) => {
        this.nativeHttp.uploadFile(url, {}, headers, [postData.url], ['file']).then(
          (res: any) => {
            console.log(res);
            if (typeof res.data === 'string' && res.data) {
              res.data = JSON.parse(res.data);
           }
            observer.next(res.data);
          }
        ).catch(
          (err: any) => {
            console.log(err, "papapa")
            if (typeof err.error === 'string') {
              err.error = JSON.parse(err.error);
            }
            console.log('error here', err);
            observer.error(err);
          }
        );
      });
    }
  }

  uploadFile(url, postData) {
    return this.httpClient.post(url, postData, {reportProgress: true, observe: 'events'});
  }

  post(url, postData, isFile = false): Observable<any> {
    this.token = localStorage.getItem("safecity_token")
    console.log(this.token, "ppp")
    if (this.platform.is('cordova')) {
      const headers: any = {};
      if (this.token) {
        headers['x-safecity-token'] = this.token
      }
      if (isFile) {
         return this.nativeFileUpload(url, postData, headers);
      } else {
        // tslint:disable-next-line: deprecation
      return Observable.create((observer: any) => {
        this.nativeHttp.setDataSerializer("json");
        this.nativeHttp.post(url, postData, headers).then((res: any) => {
          console.log(res);
          if (typeof res.data === 'string') {
             res.data = JSON.parse(res.data);
          }
          observer.next(res.data);
        }).catch(err => {
          console.log(err);
          if (typeof err.error === 'string') {
            err.error = JSON.parse(err.error);
          }
          console.log(err);
          observer.error(err);
        });
      });
      }
    } else {
      if (isFile) {
        return this.uploadFile(url, postData);
      } else {
        const headers = {}
        if (this.token) {
          headers["x-safecity-token"] = this.token;
        }
        return this.httpClient.post(url, postData, {headers});
      }
    }
    // if (isFile) {
    //   return this.uploadFile(url, postData);
    // } else {
    //   return this.httpClient.post(url, postData);
    // }
  }
}
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { CrossHttpService } from './cross-http.service';
import { map } from 'rxjs/operators';
import { StorageService } from './storage.service';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiURL = environment.base_api_url
  token = null;
  pushLogin = new BehaviorSubject(false)
  constructor(private crossHttpSvc: CrossHttpService, private storageSvc: StorageService,
    private router: Router) {
      this.getToken()
     }

  ping() {
    return this.crossHttpSvc.get(this.apiURL + `ping`);
  }

  signup(formData) {
    return this.crossHttpSvc.post(this.apiURL + `signup`, formData);
  }

  async getToken() {
    this.token = localStorage.getItem("safecity-token")
    if (this.token) {
      this.pushLogin.next(true);
    }
  }

  login(formData) {
    return this.crossHttpSvc.post(this.apiURL + `login`, formData);
  }

  verifyOtp(data) {
    return this.crossHttpSvc.post(this.apiURL + `verify-token`, data).pipe(map(p => {
      console.log(p, "lll")
      localStorage.setItem("safecity_token", p.token);
      localStorage.setItem("safecity_user", JSON.stringify(p.user));
      return p;
    }, (err: any) => {
      return err;
    }));
  }

  getUserInfo() {
    return this.crossHttpSvc.get(this.apiURL + `user-info`);
  }

  updateUserInfo(formData) {
    return this.crossHttpSvc.post(this.apiURL + `update-user`, formData);
  }

  get authToken() {
    return this.token;
  }

  logout() {
    this.storageSvc.remove('username');
    this.storageSvc.remove('firstname');
    this.storageSvc.remove('lastname');
    this.storageSvc.remove('isecure_token');
    this.router.navigate(['/login'])
  }
}

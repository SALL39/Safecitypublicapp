import { Injectable } from '@angular/core';
import { Camera, CameraResultType } from '@capacitor/camera';
import { FileChooser } from '@ionic-native/file-chooser/ngx';
import { IOSFilePicker } from '@ionic-native/file-picker/ngx';

import { Platform } from '@ionic/angular';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { VideoCapturePlus, VideoCapturePlusOptions, MediaFile } from '@ionic-native/video-capture-plus/ngx';
import { Media } from '@ionic-native/media/ngx';
import { File } from '@ionic-native/file/ngx';
import { VoiceRecorder, VoiceRecorderPlugin, RecordingData, GenericResponse } from 'capacitor-voice-recorder';

@Injectable({
  providedIn: 'root'
})
export class PhotoService {
  audio: any
  recording: boolean;
  constructor(
    private platform: Platform, private fileChooser: FileChooser,
    private filepicker: IOSFilePicker, private fileTransfer: FileTransfer,
    private videoCapturePlus: VideoCapturePlus, private media: Media,
    private file: File) { }

  public async takePicture() {
    const image = await Camera.getPhoto({
      quality: 100,
      allowEditing: false,
      correctOrientation: true,
      resultType: CameraResultType.Uri
    });
    return image;
  }

  public async chooseFile() { 
    try {
      if (this.platform.is('android')) {
          const data = await this.fileChooser.open();
          return data;
      } else if (this.platform.is('ios')) {
          const data = await this.filepicker.pickFile();
          return data;
      }
    } catch (error) {
      alert(error.message)
    } 
  }

  async fileUpload() {
    return true;
  }

  async captureVideo() {
    const options: VideoCapturePlusOptions = {
      limit: 1,
      highquality: true,
      portraitOverlay: 'assets/img/camera/overlay/portrait.png',
      landscapeOverlay: 'assets/img/camera/overlay/landscape.png'
   }
   
   const video = this.videoCapturePlus.captureVideo(options)
   return video;
  }

  async captureAudio() {
    const q = await VoiceRecorder.requestAudioRecordingPermission()
    console.log(q)
    if(q) {
      await VoiceRecorder.startRecording();
    }
  }

  async stopAudio() {
    const pp = await VoiceRecorder.stopRecording();
    return pp;
  }
  
}

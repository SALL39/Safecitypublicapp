import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { CrossHttpService } from './cross-http.service';
import { map } from 'rxjs/operators';
import { StorageService } from './storage.service';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ReportService {
  private apiURL = environment.base_api_url
  constructor(private crossHttpSvc: CrossHttpService, private storageSvc: StorageService,
    private router: Router, private http: HttpClient) {
  }

  storeReport(data) {
    return this.crossHttpSvc.post(this.apiURL + `store-regular-report`, data);
  }

  uploadReportFile(file) {
    return this.crossHttpSvc.post(this.apiURL + `upload-regular-report-file`, file, true);
  }

  uploadReportAudio(obj) {
    return this.crossHttpSvc.post(this.apiURL + `upload-report-audio`, obj);
  }

  getMyRegularReport() {
    return this.crossHttpSvc.get(this.apiURL + `my-regular-report`);
  }

  getMyEmergencyReport() {
    return this.crossHttpSvc.get(this.apiURL + `my-emergency-report`)
  }

  getLocationByLatLong(lat, long) {
    return this.http.get("https://maps.googleapis.com/maps/api/geocode/json?latlng=" + lat + "," + long + "&sensor=true&key=AIzaSyDaAqDXrqnipICgaXKP-xdmawCdEZdWdvc")
  }

  storeEmergencyReport(obj: any) {
    return this.crossHttpSvc.post(this.apiURL + `store-emergency-report`, obj);
  }

  getWantedList() {
    return this.crossHttpSvc.get(this.apiURL + `wanted-list`);
  }

  updateEmergencyLocation(formData: any) {
    return this.crossHttpSvc.post(this.apiURL + `update-emergency-location`, formData);
  }
}

import { Component, OnInit } from '@angular/core';
import { ReportService } from '../service/report.service';
import { Geolocation } from '@awesome-cordova-plugins/geolocation/ngx';
import { NotificationService } from '../service/notification.service';

@Component({
  selector: 'app-my-emergency-report',
  templateUrl: './my-emergency-report.page.html',
  styleUrls: ['./my-emergency-report.page.scss'],
})
export class MyEmergencyReportPage implements OnInit {
  report: any;
  audio: any;
  play = false;
  constructor(private reportSvc: ReportService, private geolocation: Geolocation,
    private notificationSvc: NotificationService) { }

  ngOnInit() {
    this.getMyEmergencyReport()
    this.audio = new Audio();
    this.audio.src = '/assets/4.ogg';
    this.audio.load();
    this.audio.onended = () =>{
      this.play = false;
    }
  }  

  playAudio() {
    this.audio.play();
    this.play = true;
  }

  pauseAudio() {
    this.audio.pause();
    this.play = false;
  }

  getMyEmergencyReport() {
    this.reportSvc.getMyEmergencyReport().subscribe(
      (res: any) => {
        if (res.data.length > 0) {
          this.report = res.data[0];
        }
      }
    )
  }

  updateLocation() {
    let options = {timeout: 60000, enableHighAccuracy: true, maximumAge: 3600};
    this.geolocation.getCurrentPosition(options).then(
      (result) => {
        console.log(result, "c position")
        if (!result || !result.coords) {
          this.notificationSvc.showAlert("Veuillez activer la localisation et réessayer");
        }
        this.reportSvc.getLocationByLatLong(result.coords.latitude, result.coords.longitude).subscribe(
          (res: any) => {
            console.log(res, "location name")
            const location = {
              name: res.results[5].formatted_address,
              lat: result.coords.latitude,
              long: result.coords.longitude
            }
            this.reportSvc.updateEmergencyLocation({...location, id: this.report.id}).subscribe(
              (res: any) => {
                this.notificationSvc.showToast("L'emplacement a été mis à jour avec succès")
              }
            )
          },
          (err: any) => {
            console.log(err, 'c loc err')
            this.notificationSvc.showAlert("Veuillez activer la localisation et réessayer");
          }
        )
      },
       (err: any) => {
        console.log(err, 'c pos error')
        this.notificationSvc.showAlert("Veuillez activer la localisation et réessayer");
       }
    )
  }

  ionViewWillLeave() {
    this.audio.pause();
    this.audio = null;
  }
}

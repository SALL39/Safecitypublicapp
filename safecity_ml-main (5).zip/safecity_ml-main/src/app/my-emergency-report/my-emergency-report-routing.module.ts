import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MyEmergencyReportPage } from './my-emergency-report.page';

const routes: Routes = [
  {
    path: '',
    component: MyEmergencyReportPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MyEmergencyReportPageRoutingModule {}

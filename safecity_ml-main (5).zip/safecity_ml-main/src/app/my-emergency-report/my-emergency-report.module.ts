import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MyEmergencyReportPageRoutingModule } from './my-emergency-report-routing.module';

import { MyEmergencyReportPage } from './my-emergency-report.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MyEmergencyReportPageRoutingModule
  ],
  declarations: [MyEmergencyReportPage]
})
export class MyEmergencyReportPageModule {}

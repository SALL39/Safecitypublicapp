import { Component, OnInit } from '@angular/core';
import { NotificationService } from '../service/notification.service';
import { ReportService } from '../service/report.service';

@Component({
  selector: 'app-wanted-list',
  templateUrl: './wanted-list.page.html',
  styleUrls: ['./wanted-list.page.scss'],
})
export class WantedListPage implements OnInit {
  wantedlist: any;
  selectedItem: any;
  audio: HTMLAudioElement;
  play = false
  constructor(
    private reportSvc: ReportService,
    private notifySvc: NotificationService
  ) { }

  ngOnInit() {
    this.getWantedList()
    this.audio = new Audio();
    this.audio.src = '/assets/3.ogg';
    this.audio.load();
    this.audio.onended = () =>{
      this.play = false;
    }
  }  

  playAudio() {
    this.audio.play();
    this.play = true;
  }

  pauseAudio() {
    this.audio.pause();
    this.play = false;
  }

  async getWantedList() {
    const loading = await this.notifySvc.showLoader();

    this.reportSvc.getWantedList().subscribe(
      (res: any) => {
        if (loading) {
          loading.dismiss();
        }
        this.wantedlist = res.data;
      },
      (err: any) => {
        if (loading) {
          loading.dismiss();
        }
      }
    )
  }

  view(item) {
    this.selectedItem = item;
  }

  back() {
    this.selectedItem = null;
  }

  getColor(item) {
    const obj = {
        "red": "rough",
        "yellow": "jaune",
        "white": "blanc",
        "orange": "orange",
        "black": "noir"
    }
    return obj[item];
  }

  ionViewWillLeave() {
    this.audio.pause();
    this.audio = null;
  }
}

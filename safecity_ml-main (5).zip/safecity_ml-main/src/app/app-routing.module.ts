import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./tab1/tab1.module').then(m => m.Tab1PageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'signup',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'forgetpass',
    loadChildren: () => import('./forgetpass/forgetpass.module').then( m => m.ForgetpassPageModule)
  },
  {
    path: 'trackvictim',
    loadChildren: () => import('./trackvictim/trackvictim.module').then( m => m.TrackvictimPageModule)
  },
  {
    path: 'my-profile',
    loadChildren: () => import('./my-profile/my-profile.module').then( m => m.MyProfilePageModule)
  },
  {
    path: 'my-regular-report',
    loadChildren: () => import('./my-regular-report/my-regular-report.module').then( m => m.MyRegularReportPageModule)
  },
  {
    path: 'my-emergency-report',
    loadChildren: () => import('./my-emergency-report/my-emergency-report.module').then( m => m.MyEmergencyReportPageModule)
  },
  {
    path: 'wanted-list',
    loadChildren: () => import('./wanted-list/wanted-list.module').then( m => m.WantedListPageModule)
  },
  {
    path: 'green-numbers',
    loadChildren: () => import('./green-numbers/green-numbers.module').then( m => m.GreenNumbersPageModule)
  }
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trackvictim',
  templateUrl: './trackvictim.page.html',
  styleUrls: ['./trackvictim.page.scss'],
})
export class TrackvictimPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TrackvictimPage } from './trackvictim.page';

const routes: Routes = [
  {
    path: '',
    component: TrackvictimPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TrackvictimPageRoutingModule {}

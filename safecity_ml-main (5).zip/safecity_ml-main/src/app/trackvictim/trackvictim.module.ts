import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TrackvictimPageRoutingModule } from './trackvictim-routing.module';

import { TrackvictimPage } from './trackvictim.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TrackvictimPageRoutingModule
  ],
  declarations: [TrackvictimPage]
})
export class TrackvictimPageModule {}

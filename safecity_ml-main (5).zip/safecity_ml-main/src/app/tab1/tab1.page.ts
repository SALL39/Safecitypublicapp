import { Component, OnDestroy } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { ActionSheetController } from '@ionic/angular';
import { NotificationService } from '../service/notification.service';
import { PhotoService } from '../service/photo.service';
import { ReportService } from '../service/report.service';
import { UserService } from '../service/user.service';
import { VoiceRecorderService } from '../service/voice-recorder.service';
import { Geolocation } from '@awesome-cordova-plugins/geolocation/ngx';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page{
  audio: any;
  step = 1;
  reporttype: any = null;
  filetype: string;
  filename: string;
  file: string;
  timer: number;
  audioData: any;
  isrecording = false;
  myinterval: any;
  base64data: string;
  fileurl: any;
  show_identity: any = false;
  description = ""
  isprocess = 1
  timing = "02:00";
  recordinterval: any;
  recordedAudio: any;
  audioFileName: any;
  audiourl = environment.audio_url;
  location: any;
  play: boolean;
  constructor(private action: ActionSheetController, private reportSvc: ReportService,
    private photoSvc: PhotoService, private sanitizer: DomSanitizer,
    private route: ActivatedRoute, private userSvc: UserService,
    private recorderSvc: VoiceRecorderService,
    private geolocation: Geolocation,
    private router: Router,
    private notificationSvc: NotificationService) {
      this.route.params.subscribe((v) => {
        this.reset();
      })
      this.ping() 
    }

  ionViewDidEnter() {
    this.getLocation();
    this.audio = new Audio();
    this.audio.src = '/assets/1.ogg';
    this.audio.load();
    this.audio.onended = () =>{
      this.play = false;
    }
  }  

  playAudio() {
    this.audio.play();
    this.play = true;
  }

  pauseAudio() {
    this.audio.pause();
    this.play = false;
  }

  ping() {
    this.userSvc.ping().subscribe()
  }  

  getLocationPromise = () => new Promise((resolve, reject) => 
  navigator.geolocation.getCurrentPosition(resolve, reject));


  async getLocation() { 
    let location: any = await this.getLocationPromise();
    this.location = {};
    this.location.lat = location.coords.latitude
    this.location.long = location.coords.longitude
    console.log(this.location, location, "12")
    // navigator.geolocation.getCurrentPosition((pos) => {
    //   console.log(pos.coords.latitude, pos.coords.longitude, "11")
    //   console.log(this.location, "12")
    //   this.location.lat = pos.coords.latitude
    //   this.location.long = pos.coords.longitude
    //   // this.reportSvc.getLocationByLatLong(crd.latitude, crd.longitude).subscribe(
    //   //   (res: any) => {
    //   //     console.log(res, "location name")
    //   //     this.location.name = res.results[5].formatted_address
    //   //   },
    //   //   (err: any) => {
    //   //     this.notificationSvc.showAlert("Veuillez activer la localisation et réessayer");
    //   //   }
    //   // )
    // }, () => {}, {enableHighAccuracy:true});
  }

  async onAddAttachment() {
    const actionSheet = await this.action.create({
      header: 'Choisissez une action',
      buttons: [
      {
        text: 'Prendre une photo',
        icon: 'camera',
        handler: () => {
          this.takePicture();
        }
      },
      {
        text: 'Prenez la vidéo',
        icon: 'videocam',
        handler: () => {
          this.takeVideo()
        }
      }, 
      // {
      //   text: 'Record Audio',
      //   icon: 'mic',
      //   handler: () => {
      //     this.showAudio()
      //   }
      // },
      {
        // text: 'Upload Photo/Audio/Video',
        text: 'Télécharger la photo',
        icon: 'cloud-upload',
        handler: () => {
          this.uploadFile();
        }
      },
      {
        text: 'Passer à',
        icon: 'close',
        handler: () => {
          this.filetype = "skip"
        }
      }]
    });
    await actionSheet.present();
  }

  async saveFileToServer(url) {
    const loading = await this.notificationSvc.showLoader();
    this.reportSvc.uploadReportFile({url}).subscribe(
      (res: any) => {
        this.file = res.filename;
        this.fileurl = res.fileurl;
        if (!this.filetype && res.type) {
          this.filetype = res.type == "image" ? "photo" : res.type;
        }
        loading.dismiss();
      },
      (err: any) => {
        console.log(err)
        loading.dismiss();
      }
    )
  }

  async takePicture() {
    const pp = await this.photoSvc.takePicture();
    this.filetype= "photo";
    this.file = pp.path; 
    this.saveFileToServer(this.file);
  }

  async takeVideo() {
    const pp: any = await this.photoSvc.captureVideo()
    this.filetype = "video"
    this.saveFileToServer(pp[0].fullPath)
  }

  async uploadFile() {
    const pp: any = await this.photoSvc.chooseFile();
    this.saveFileToServer(pp)
  }

  showAudio() {
    this.filetype = "audio"
  }

  async recordAudio() {
    if (!this.timer) {
      this.isrecording = true;
      this.timer = 10;
      this.photoSvc.captureAudio();
      this.myinterval = setInterval(async () => {
        this.timer--;
        if (this.timer <= 0) {
          this.isrecording = false;
          clearInterval(this.myinterval);
          this.audioData = await this.photoSvc.stopAudio()
          console.log(this.audioData)
        }
      }, 1000);
    }

  }

  async getAudioData() {
    this.timer = null;
    this.isrecording = false;
    clearInterval(this.myinterval);
    this.audioData = this.photoSvc.stopAudio()
    console.log(this.audioData)
  }

  async showReportType() {
    const actionSheet = await this.action.create({
      header: 'Choisissez une option',
      buttons: [
      {
        text: 'Terrorisme',
        icon: 'arrow-forward',
        handler: () => {
          this.reporttype = 'Terrorisme';
          this.isprocess = 1
        }
      },
      {
        text: 'Contrebande',
        icon: 'arrow-forward',
        handler: () => {
          this.reporttype = 'Contrebande';
          this.isprocess = 1
        }
      },
      {
        text: 'Traffic de stupéfiants',
        icon: 'arrow-forward',
        handler: () => {
          this.reporttype = 'Traffic de stupéfiants';
          this.isprocess = 1
        }
      },
      {
        text: 'Enlèvement avec risque pour la vie',
        icon: 'arrow-forward',
        handler: () => {
          this.reporttype = 'Enlèvement avec risque pour la vie ';
          this.isprocess = 1
        }
      },
      {
        text: 'Accident de la circulation',
        icon: 'arrow-forward',
        handler: () => {
          this.reporttype = 'Accident de la circulation';
          this.isprocess = 1
        }
      },
      {
        text: 'Incendie',
        icon: 'arrow-forward',
        handler: () => {
          this.reporttype = 'Incendie';
          this.isprocess = 1
        }
      },
      {
        text: 'Trouble à l\'ordre public',
        icon: 'arrow-forward',
        handler: () => {
          this.reporttype = 'Trouble à l\'ordre public';
          this.isprocess = 1
        }
      },
      {
        text: 'Autre ( à préciser en détails)',
        icon: 'arrow-forward',
        handler: () => {
          this.reporttype = 'Autre ( à préciser en détails)';
          this.isprocess = 1
        }
      },
      ]
    });
    await actionSheet.present();
  }

  submit() {
    this.getLocation();
    // this.location = {name: "Bamako", lat: 12.635898, long: -7.971547}
    const data = {filetype: this.filetype, file: this.file, show_identity: this.show_identity,
                  audioFileName: this.audioFileName,
                location: this.location};
    if (!this.audioFileName) {
      this.notificationSvc.showAlert("Veuillez ajouter un fichier ou une description")
      return false;
    }
    if (!this.location || !(this.location.lat && this.location.long)) {
      this.notificationSvc.showAlert("Veuillez activer la localisation et réessayer")
      return false;
    }

    this.location.name = !this.location.name ? "Unrecognized" : this.location.name;
    this.reportSvc.storeReport(data).subscribe(
      (res: any) => {
        console.log(res);
        this.reset()
        this.notificationSvc.showToast("Le rapport a été envoyé au poste de police voisin avec succès.")
      }
    )
  } 

  reset() {
    this.filetype = null;
    this.file = null;
    this.fileurl = null;
    this.description = null;
    this.show_identity = false;
    this.isprocess = 1
    this.recordedAudio = null;
    this.isrecording = false;
  }

  getAudioContent() {
    return this.sanitizer.bypassSecurityTrustUrl(this.audioData.value.recordDataBase64);
  }

  async startRecording() {
    this.recordedAudio = null;
    this.isrecording = true;
    this.timing = "02:00"
    const p = await this.recorderSvc.startRecording();
    if (p.success) {
      this.recordinterval = setInterval(() => {
        const t = this.timing.split(":")
        let t1: any = Number(t[0]);
        let t2: any = Number(t[1])
        if (Number(t2) == 0) {
          t2 = 59;
          t1 = Number(t1) - 1;
          if (t1 < 0) {
            this.stopRecording();
          }
        } else {
          t2 = t2 - 1;
        }
        this.timing = ((t1 > 9) ? t1 : "0" + t1) + ":" + ((t2 > 9) ? t2 : "0" + t2)
      }, 1000)
    } else {
      this.isrecording = false;
    }
    
  }

  async stopRecording() {
    this.audioFileName = null
    this.isrecording = false;
    if (this.recordinterval) {
      clearInterval(this.recordinterval)
      this.isrecording = false;
      this.timer = null;
    }
    const d: any = await this.recorderSvc.stopRecording();
    this.recordedAudio = this.sanitizer.bypassSecurityTrustResourceUrl(d.value.recordDataBase64);
    this.reportSvc.uploadReportAudio({...d}).subscribe(
      (res: any) => {
        console.log(res, "sddd")
        if (res["filename"]) {
          this.audioFileName = res["filename"];
        }
      }
    )
  }

  navigateGreenPage() {
    this.router.navigate(["/green-numbers"])
  }

  ionViewWillLeave() {
    this.audio.pause();
  }
}

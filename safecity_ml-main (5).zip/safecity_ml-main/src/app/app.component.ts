import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from './service/user.service';
import { BackgroundMode } from '@awesome-cordova-plugins/background-mode/ngx';
import { Platform } from '@ionic/angular';
import { AndroidPermissions } from '@awesome-cordova-plugins/android-permissions/ngx';
import { NotificationService } from './service/notification.service';
import { Geolocation } from '@awesome-cordova-plugins/geolocation/ngx';
import { ReportService } from './service/report.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  volumepressed: any;
  location: { name: any; lat: number; long: number; };
  issaving = false;
  constructor(private router: Router, private userSvc: UserService,
    private backgroundMode: BackgroundMode, private platform: Platform,
    private androidPermissions: AndroidPermissions,
    private geolocation: Geolocation,
    private notificationSvc: NotificationService,
    private reportSvc: ReportService) {
    const token = localStorage.getItem("safecity_token");
    if (token) {
      this.router.navigate(['/'])
    } else {
      this.router.navigate(['/login'])
    }
    this.platform.ready().then(() => {
      this.setVolumeButton();
      this.checkPermission();
      this.backgroundMode.enable();
    })
  }

  getLocationPromise = () => new Promise((resolve, reject) => 
  navigator.geolocation.getCurrentPosition(resolve, reject));

  async getLocation() {
    const location: any = await this.getLocationPromise();
    this.location = {
      name: "Unrecognized",
      lat: location.coords.latitude,
      long: location.coords.longitude
    }
    if (!this.issaving) {
      this.issaving = true;
      this.reportSvc.storeEmergencyReport(this.location).subscribe(
        (res: any) => {
          this.issaving = false;
          this.notificationSvc.showAlert("Alerte d'urgence envoyée. Veuillez être patient et attendre dans un endroit sûr")
        },
        (err) => {
          this.issaving = false;
          if (err.error && err.error.message) {
            this.notificationSvc.showAlert(err.error.message)
          }
        }
      )
    }
  }

  navigate(page) {
    this.router.navigate([page]);
  }

  setVolumeButton() {
    window.addEventListener("volumebuttonslistener", () => {
      if (!this.volumepressed) {
        this.volumepressed = 1;
        setTimeout(() => {
          this.volumepressed = null;
        }, 3000);
      } else {
        this.volumepressed += 1;
        if (this.volumepressed == 3) {
          this.getLocation()
        }
      }
    }, false);
  }

  checkPermission() {
    this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.ACCESS_COARSE_LOCATION);
    this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.ACCESS_COARSE_LOCATION).then(
      result => {
        if (!result.hasPermission) {
          this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.ACCESS_COARSE_LOCATION);
          this.checkPermission()
        }
      }
    );
  }

  logout() {
    this.userSvc.logout()
  }
}

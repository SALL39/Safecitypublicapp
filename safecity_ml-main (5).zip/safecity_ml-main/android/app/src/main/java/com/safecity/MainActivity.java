package com.safecity;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
